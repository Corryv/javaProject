/**
 * Group: Corry Vantienen, Seth Edwards, Julie Jimenez, Melissa Lopez, Nicholas Foster
 * CSC 331
 * Date: 11/23/2025
 */
package com.example.draw;

import javafx.application.Application;

public class Launcher {
    public static void main(String[] args) {
        Application.launch(DrawApplication.class, args);
    }
}
